/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eserciziocampane;

/**
 *
 * @author informatica
 */
public class Thread1 extends Thread {
    public int c;
    public Thread1(int c) {
        this.c = c;
    }
    
    @Override
    public void run(){
       while(1==1){
           for (this.c=0;this.c<100;this.c++){
               System.out.println(this.c);
           }
       }
    }
}
